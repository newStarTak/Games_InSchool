import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
//C:\Users\202010936\Desktop\KGT\Java Collection\1_2(Java)\YachtImg\Ace.png

public class Main extends Categories
{
    public static void main (String[] args)
    {
        game_Frame gf = new game_Frame();

        Player player = new Player();
        player.Show();

        // 김근탁이 만든 구버전 - UI 창 생성
        //JFrame UI = new JFrame("짜잔");
        //UI.setBounds(50,25,1000,1000);
        //UI.setVisible(true);
        //UI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //UI.setResizable(false);

        //try
        //{
        //UI.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("YachtDice.png")))));
        //} catch (
        //IOException e) {
        //e.printStackTrace();
        //}
    }
}

// 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 //
// 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 //
// 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 // 편의를 위한 구분선 //

class Player extends Categories
{
    JLabel bonus_label_p1 = new JLabel("+35");
    static JLabel subtotal_label_p1 = new JLabel("0 / 63");
    static JLabel total_Label_p1 = new JLabel("0");
    static JButton AcesButton_p1 = new JButton("?");
    static JButton DeuceButton_p1 = new JButton("?");
    static JButton ThreesButton_p1 = new JButton("?");
    static JButton FoursButton_p1 = new JButton("?");
    static JButton FivesButton_p1 = new JButton("?");
    static JButton SixesButton_p1 = new JButton("?");
    static JButton ChoiceButton_p1 = new JButton("?");
    static JButton FourOfKindButton_p1 = new JButton("?");
    static JButton FullHouseBUtton_p1 = new JButton("?");
    static JButton S_StraightButton_p1 = new JButton("?");
    static JButton L_StraightButton_p1 = new JButton("?");
    static JButton YachtButton_p1 =new JButton("?");
    JLabel bonus_label_p2 = new JLabel("+35");
    static JLabel subtotal_label_p2 = new JLabel("0 / 63"); // p2 subtotal 라벨 추가
    static JLabel total_Label_p2 = new JLabel("0");
    static JButton AcesButton_p2 = new JButton("?");
    static JButton DeuceButton_p2 = new JButton("?");
    static JButton ThreesButton_p2 = new JButton("?");
    static JButton FoursButton_p2 = new JButton("?");
    static JButton FivesButton_p2 = new JButton("?");
    static JButton SixesButton_p2 = new JButton("?");
    static JButton ChoiceButton_p2 = new JButton("?");
    static JButton FourOfKindButton_p2 = new JButton("?");
    static JButton FullHouseBUtton_p2 = new JButton("?");
    static JButton S_StraightButton_p2 = new JButton("?");
    static JButton L_StraightButton_p2 = new JButton("?");
    static JButton YachtButton_p2 =new JButton("?");
    static JLabel Turn_Label = new JLabel();

    //잠그기 및 풀기 변수 - 잠근 상태 0, 푼 상태 1
    static int d1lock = 1;
    static int d2lock = 1;
    static int d3lock = 1;
    static int d4lock = 1;
    static int d5lock = 1;

    static int d1 = 0;
    static int d2 = 0;
    static int d3 = 0;
    static int d4 = 0;
    static int d5 = 0;

    // 0이면 보너스 못 받은 상태, 1이면 보너스 이미 받은 상태
    static int subtotal_p1 = 0;
    static int subtotal_p2 = 0;

    // P1 - 0, P2 - 1
    //int T = 0;
    // 3회 굴리기 남은 횟수
    static int count = 0;
    static int total_turn = 0;



    //private int Aces, Deuces, Threes, Fours, Fives, Sixes, Choice, FourOfKind, FullHouse, S_Straight, L_Straight, Yacht;

    public void player1(int aces, int deuces, int threes, int fours, int fives, int sixes, int choice, int fourOfKind, int fullHouse, int s_straight, int l_straight, int yacht)
    {

    }
    public void player2(int aces, int deuces, int threes, int fours, int fives, int sixes, int choice, int fourOfKind, int fullHouse, int s_straight, int l_straight, int yacht)
    {

    }

    public void Show()
    {
        JFrame UI = new JFrame("족보");
        try {
            UI.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("YachtDice.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }
        UI.pack();
        int f_xpos = 250;//(int)(screen.getWidth() / 2 - f_width / 2);
        int f_ypos = 125;//(int)(screen.getHeight() / 2 - f_height / 2);

        UI.setLocation(f_xpos, f_ypos);
        UI.setVisible(true);
        UI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        UI.setResizable(false);

        JButton b1 = new JButton("잠그기_1");
        JButton b2 = new JButton("잠그기_2");
        JButton b3 = new JButton("잠그기_3");
        JButton b4 = new JButton("잠그기_4");
        JButton b5 = new JButton("잠그기_5");
        JButton b6 = new JButton("버그킬러");

        UI.add(b1);
        UI.add(b2);
        UI.add(b3);
        UI.add(b4);
        UI.add(b5);
        UI.add(b6);
        //7번째 버튼을 추가는 하지만 Visible_false해줌

        b1.setBounds(50, 580, 100, 100);
        b2.setBounds(220, 580, 100, 100);
        b3.setBounds(390, 580, 100, 100);
        b4.setBounds(135, 690, 100, 100);
        b5.setBounds(305, 690, 100, 100);

        b6.setVisible(false);
        //버그킬러용 7번째 버튼 비활성화

        b1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //JButton b1 = (JButton) e.getSource();
                if(b1.getText().equals("잠그기_1") && count != 0)
                {
                    b1.setText("풀기_1");
                    d1lock = 0;
                }
                else
                {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                }

            }
        });

        b2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //JButton b2 = (JButton) e.getSource();
                if(b2.getText().equals("잠그기_2") && count != 0)
                {
                    b2.setText("풀기_2");
                    d2lock = 0;
                }
                else {
                    b2.setText("잠그기_2");
                    d2lock = 1;
                }
            }
        });

        b3.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //JButton b3 = (JButton) e.getSource();
                if(b3.getText().equals("잠그기_3") && count != 0)
                {
                    b3.setText("풀기_3");
                    d3lock = 0;
                }
                else
                {
                    b3.setText("잠그기_3");
                    d3lock = 1;
                }
            }
        });

        b4.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //JButton b4 = (JButton) e.getSource();
                if(b4.getText().equals("잠그기_4") && count != 0)
                {
                    b4.setText("풀기_4");
                    d4lock = 0;
                }
                else
                {
                    b4.setText("잠그기_4");
                    d4lock = 1;
                }
            }
        });

        b5.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //JButton b5 = (JButton) e.getSource();
                if(b5.getText().equals("잠그기_5") && count != 0)
                {
                    b5.setText("풀기_5");
                    d5lock = 0;
                }
                else
                {
                    b5.setText("잠그기_5");
                    d5lock = 1;
                }
            }
        });

        // 버그킬러 버튼 (무시)
        JButton bk = new JButton("버그킬러");
        UI.add(bk);
        bk.setBounds(0, 50, 500, 50);
        bk.setVisible(false);

        /*if(subtotal[T]>= 63) { // p1 보너스 라벨 추가
            if(subtotal_p1 == 0)
            {
                total_score[T] += 35;
                subtotal_p1 = 1;
            }

            UI.add(bonus_label_p1);
            bonus_label_p1.setBounds(290, 300, 100, 30);
        }


        subtotal_label_p1.setText(""+subtotal[T]);
        UI.add(subtotal_label_p1);
        subtotal_label_p1.setBounds(290,270,100,30);

        if(subtotal[T]>= 63) { // p2 보너스 라벨 추가
            if(subtotal_p2 == 0)
            {
                total_score[T] += 35;
                subtotal_p2 = 1;
            }
            UI.add(bonus_label_p2);
            bonus_label_p2.setBounds(430, 300, 100, 30);
        }*/
        subtotal_label_p1.setText(String.valueOf(subtotal[0]) + " / 63");
        UI.add(subtotal_label_p1);
        subtotal_label_p1.setBounds(290,270,100,30);
        total_Label_p1.setText(String.valueOf(total_score[0]));
        UI.add(total_Label_p1);
        total_Label_p1.setBounds(290,515,100,50);

        subtotal_label_p2.setText(String.valueOf(subtotal[1]) + " / 63");
        UI.add(subtotal_label_p2);
        subtotal_label_p2.setBounds(430,270,100,30);
        total_Label_p2.setText(String.valueOf(total_score[1]));
        UI.add(total_Label_p2);
        total_Label_p2.setBounds(430,515,100,50);

        UI.add(Turn_Label);
        Turn_Label.setText("Turn : "+(total_turn/2+1)+" / 12" + " - P" + (T + 1) + " Turn");
        Turn_Label.setBounds(100, 50, 200, 50);

        UI.add(AcesButton_p1);
        UI.add(DeuceButton_p1);
        UI.add(ThreesButton_p1);
        UI.add(FoursButton_p1);
        UI.add(FivesButton_p1);
        UI.add(SixesButton_p1);
        UI.add(ChoiceButton_p1);
        UI.add(FourOfKindButton_p1);
        UI.add(FullHouseBUtton_p1);
        UI.add(S_StraightButton_p1);
        UI.add(L_StraightButton_p1);
        UI.add(YachtButton_p1);
        AcesButton_p1.setBounds(285, 88, 100, 30);
        DeuceButton_p1.setBounds(285, 120, 100,30);
        ThreesButton_p1.setBounds(285,150,100,30);
        FoursButton_p1.setBounds(285,180,100,30);
        FivesButton_p1.setBounds(285,210,100,30);
        SixesButton_p1.setBounds(285,240,100,30);
        ChoiceButton_p1.setBounds(285, 330,100,30);
        FourOfKindButton_p1.setBounds(285, 360,100,30);
        FullHouseBUtton_p1.setBounds(285,387,100,30);
        S_StraightButton_p1.setBounds(285,420,100,30);
        L_StraightButton_p1.setBounds(285,450,100,30);
        YachtButton_p1.setBounds(285,482,100,30);

        Player1 p1 = new Player1();
        Player2 p2 = new Player2();

        AcesButton_p1.addActionListener(new ActionListener() // 변수 수정
        {
            public void actionPerformed(ActionEvent e)
            {
                if (count != 0 && T == 0)
                {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    AcesButton_p1.setVisible(false);
                    JLabel AcesLabel_p1 = new JLabel(""+Aces);
                    UI.add(AcesLabel_p1);
                    AcesLabel_p1.setBounds(290,90,100,30);
                    total_score[0] += Aces;
                    subtotal[0] += Aces;
                    if(subtotal[0]>= 63) { // p1 보너스 라벨 추가
                        if (subtotal_p1 == 0) {
                            total_score[0] += 35;
                            subtotal_p1 = 1;
                        }

                        UI.add(bonus_label_p1);
                        bonus_label_p1.setBounds(290, 300, 100, 30);
                    }
                    T = turn_change(T); //turn은 전체 변수이기때문에 하나만 바꿔도 전체가 바뀌는 것이 원하는 바임
                    BtnReset();
                    count=0;
                    total_turn++;
                    p1.Aces_f1(Aces);
                    end_f();
                    Aces = 0; Deuces = 0; Threes = 0; Fours = 0; Fives = 0; Sixes = 0;
                    Choice = 0; FourOfKind = 0; FullHouse = 0; S_Straight = 0; L_Straight = 0; Yacht = 0;
                }
            }
        });
        DeuceButton_p1.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    DeuceButton_p1.setVisible(false);
                    JLabel DeuceLabel_p1 = new JLabel("" + Deuces);
                    UI.add(DeuceLabel_p1);
                    DeuceLabel_p1.setBounds(290, 120, 100, 30);
                    total_score[0] += Deuces;
                    subtotal[0] += Deuces;
                    if (subtotal[0] >= 63) { // p1 보너스 라벨 추가
                        if (subtotal_p1 == 0) {
                            total_score[0] += 35;
                            subtotal_p1 = 1;
                        }

                        UI.add(bonus_label_p1);
                        bonus_label_p1.setBounds(290, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.Deuces_f1(Deuces);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        ThreesButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    ThreesButton_p1.setVisible(false);
                    JLabel ThreesLabel_p1 = new JLabel("" + Threes);
                    UI.add(ThreesLabel_p1);
                    ThreesLabel_p1.setBounds(290, 150, 100, 30);
                    total_score[0] += Threes;
                    subtotal[0] += Threes;
                    if (subtotal[0] >= 63) { // p1 보너스 라벨 추가
                        if (subtotal_p1 == 0) {
                            total_score[0] += 35;
                            subtotal_p1 = 1;
                        }

                        UI.add(bonus_label_p1);
                        bonus_label_p1.setBounds(290, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.threes_f1(Threes);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FoursButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FoursButton_p1.setVisible(false);
                    JLabel FoursLabel_p1 = new JLabel("" + Fours);
                    UI.add(FoursLabel_p1);
                    FoursLabel_p1.setBounds(290, 180, 100, 30);
                    total_score[0] += Fours;
                    subtotal[0] += Fours;
                    if (subtotal[0] >= 63) { // p1 보너스 라벨 추가
                        if (subtotal_p1 == 0) {
                            total_score[0] += 35;
                            subtotal_p1 = 1;
                        }

                        UI.add(bonus_label_p1);
                        bonus_label_p1.setBounds(290, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.fours_f1(Fours);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FivesButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FivesButton_p1.setVisible(false);
                    JLabel FivesLabel_p1 = new JLabel("" + Fives);
                    UI.add(FivesLabel_p1);
                    FivesLabel_p1.setBounds(290, 210, 100, 30);
                    total_score[0] += Fives;
                    subtotal[0] += Fives;
                    if (subtotal[0] >= 63) { // p1 보너스 라벨 추가
                        if (subtotal_p1 == 0) {
                            total_score[0] += 35;
                            subtotal_p1 = 1;
                        }

                        UI.add(bonus_label_p1);
                        bonus_label_p1.setBounds(290, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.fives_f1(Fives);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        SixesButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    SixesButton_p1.setVisible(false);
                    JLabel SixesLabel_p1 = new JLabel("" + Sixes);
                    UI.add(SixesLabel_p1);
                    SixesLabel_p1.setBounds(290, 240, 100, 30);
                    total_score[0] += Sixes;
                    subtotal[0] += Sixes;
                    if (subtotal[0] >= 63) { // p1 보너스 라벨 추가
                        if (subtotal_p1 == 0) {
                            total_score[0] += 35;
                            subtotal_p1 = 1;
                        }

                        UI.add(bonus_label_p1);
                        bonus_label_p1.setBounds(290, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.sixes_f1(Sixes);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        ChoiceButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    ChoiceButton_p1.setVisible(false);
                    JLabel ChoiceLabel_p1 = new JLabel("" + Choice);
                    total_score[0] += Choice;
                    UI.add(ChoiceLabel_p1);
                    ChoiceLabel_p1.setBounds(290, 335, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.choices_f1(Choice);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FourOfKindButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FourOfKindButton_p1.setVisible(false);
                    JLabel FourOfKindLabel_p1 = new JLabel("" + FourOfKind);
                    total_score[0] += FourOfKind;
                    UI.add(FourOfKindLabel_p1);
                    FourOfKindLabel_p1.setBounds(290, 365, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.fourofkind_f1(FourOfKind);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FullHouseBUtton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FullHouseBUtton_p1.setVisible(false);
                    JLabel FullHouseLabel_p1 = new JLabel("" + FullHouse);
                    total_score[0] += FullHouse;
                    UI.add(FullHouseLabel_p1);
                    FullHouseLabel_p1.setBounds(290, 395, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.fullhouse_f1(FullHouse);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        S_StraightButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    S_StraightButton_p1.setVisible(false);
                    JLabel S_StraightLabel_p1 = new JLabel("" + S_Straight);
                    total_score[0] += S_Straight;
                    UI.add(S_StraightLabel_p1);
                    S_StraightLabel_p1.setBounds(290, 425, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.s_straight_f1(S_Straight);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        L_StraightButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    L_StraightButton_p1.setVisible(false);
                    JLabel L_StraightLabel_p1 = new JLabel("" + L_Straight);
                    total_score[0] += L_Straight;
                    UI.add(L_StraightLabel_p1);
                    L_StraightLabel_p1.setBounds(290, 455, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.l_straight_f1(L_Straight);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        YachtButton_p1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 0) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    YachtButton_p1.setVisible(false);
                    JLabel YachtLabel_p1 = new JLabel("" + Yacht);
                    total_score[0] += Yacht;
                    UI.add(YachtLabel_p1);
                    YachtLabel_p1.setBounds(290, 485, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p1.yacht_f1(Yacht);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });

        UI.add(AcesButton_p2);
        UI.add(DeuceButton_p2);
        UI.add(ThreesButton_p2);
        UI.add(FoursButton_p2);
        UI.add(FivesButton_p2);
        UI.add(SixesButton_p2);
        UI.add(ChoiceButton_p2);
        UI.add(FourOfKindButton_p2);
        UI.add(FullHouseBUtton_p2);
        UI.add(S_StraightButton_p2);
        UI.add(L_StraightButton_p2);
        UI.add(YachtButton_p2);
        AcesButton_p2.setBounds(425, 88, 100, 30);
        DeuceButton_p2.setBounds(425, 120, 100,30);
        ThreesButton_p2.setBounds(425,150,100,30);
        FoursButton_p2.setBounds(425,180,100,30);
        FivesButton_p2.setBounds(425,210,100,30);
        SixesButton_p2.setBounds(425,240,100,30);
        ChoiceButton_p2.setBounds(425, 330,100,30);
        FourOfKindButton_p2.setBounds(425, 360,100,30);
        FullHouseBUtton_p2.setBounds(425,387,100,30);
        S_StraightButton_p2.setBounds(425,420,100,30);
        L_StraightButton_p2.setBounds(425,450,100,30);
        YachtButton_p2.setBounds(425,482,100,30);

        AcesButton_p2.addActionListener(new ActionListener() // 변수 수정
        {
            public void actionPerformed(ActionEvent e)
            {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    AcesButton_p2.setVisible(false);
                    JLabel AcesLabel_p2 = new JLabel("" + Aces);
                    UI.add(AcesLabel_p2);
                    AcesLabel_p2.setBounds(430, 90, 100, 30);
                    total_score[1] += Aces;
                    subtotal[1] += Aces;
                    if (subtotal[1] >= 63) { // p2 보너스 라벨 추가
                        if (subtotal_p2 == 0) {
                            total_score[T] += 35;
                            subtotal_p2 = 1;
                        }
                        UI.add(bonus_label_p2);
                        bonus_label_p2.setBounds(430, 300, 100, 30);
                    }
                    T = turn_change(T); //turn은 전체 변수이기때문에 하나만 바꿔도 전체가 바뀌는 것이 원하는 바임
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.Aces_f2(Aces);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        DeuceButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    DeuceButton_p2.setVisible(false);
                    JLabel DeuceLabel_p2 = new JLabel("" + Deuces);
                    UI.add(DeuceLabel_p2);
                    DeuceLabel_p2.setBounds(430, 120, 100, 30);
                    total_score[1] += Deuces;
                    subtotal[1] += Deuces;
                    if (subtotal[1] >= 63) { // p2 보너스 라벨 추가
                        if (subtotal_p2 == 0) {
                            total_score[T] += 35;
                            subtotal_p2 = 1;
                        }
                        UI.add(bonus_label_p2);
                        bonus_label_p2.setBounds(430, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.Deuces_f2(Deuces);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        ThreesButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    ThreesButton_p2.setVisible(false);
                    JLabel ThreesLabel_p2 = new JLabel("" + Threes);
                    UI.add(ThreesLabel_p2);
                    ThreesLabel_p2.setBounds(430, 150, 100, 30);
                    total_score[1] += Threes;
                    subtotal[1] += Threes;
                    if (subtotal[1] >= 63) { // p2 보너스 라벨 추가
                        if (subtotal_p2 == 0) {
                            total_score[T] += 35;
                            subtotal_p2 = 1;
                        }
                        UI.add(bonus_label_p2);
                        bonus_label_p2.setBounds(430, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.threes_f2(Threes);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FoursButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FoursButton_p2.setVisible(false);
                    JLabel FoursLabel_p2 = new JLabel("" + Fours);
                    UI.add(FoursLabel_p2);
                    FoursLabel_p2.setBounds(430, 180, 100, 30);
                    total_score[1] += Fours;
                    subtotal[1] += Fours;
                    if (subtotal[1] >= 63) { // p2 보너스 라벨 추가
                        if (subtotal_p2 == 0) {
                            total_score[T] += 35;
                            subtotal_p2 = 1;
                        }
                        UI.add(bonus_label_p2);
                        bonus_label_p2.setBounds(430, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.fours_f2(Fours);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FivesButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FivesButton_p2.setVisible(false);
                    JLabel FivesLabel_p2 = new JLabel("" + Fives);
                    UI.add(FivesLabel_p2);
                    FivesLabel_p2.setBounds(430, 210, 100, 30);
                    total_score[1] += Fives;
                    subtotal[1] += Fives;
                    if (subtotal[1] >= 63) { // p2 보너스 라벨 추가
                        if (subtotal_p2 == 0) {
                            total_score[T] += 35;
                            subtotal_p2 = 1;
                        }
                        UI.add(bonus_label_p2);
                        bonus_label_p2.setBounds(430, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.fives_f2(Fives);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        SixesButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    SixesButton_p2.setVisible(false);
                    JLabel SixesLabel_p2 = new JLabel("" + Sixes);
                    UI.add(SixesLabel_p2);
                    SixesLabel_p2.setBounds(430, 240, 100, 30);
                    total_score[1] += Sixes;
                    subtotal[1] += Sixes;
                    if (subtotal[1] >= 63) { // p2 보너스 라벨 추가
                        if (subtotal_p2 == 0) {
                            total_score[T] += 35;
                            subtotal_p2 = 1;
                        }
                        UI.add(bonus_label_p2);
                        bonus_label_p2.setBounds(430, 300, 100, 30);
                    }
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.sixes_f2(Sixes);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        ChoiceButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    ChoiceButton_p2.setVisible(false);
                    JLabel ChoiceLabel_p2 = new JLabel("" + Choice);
                    total_score[1] += Choice;
                    UI.add(ChoiceLabel_p2);
                    ChoiceLabel_p2.setBounds(430, 335, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.choices_f2(Choice);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FourOfKindButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FourOfKindButton_p2.setVisible(false);
                    JLabel FourOfKindLabel_p2 = new JLabel("" + FourOfKind);
                    total_score[1] += FourOfKind;
                    UI.add(FourOfKindLabel_p2);
                    FourOfKindLabel_p2.setBounds(430, 365, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.fourofkind_f2(FourOfKind);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        FullHouseBUtton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    FullHouseBUtton_p2.setVisible(false);
                    JLabel FullHouseLabel_p2 = new JLabel("" + FullHouse);
                    total_score[1] += FullHouse;
                    UI.add(FullHouseLabel_p2);
                    FullHouseLabel_p2.setBounds(430, 395, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.fullhouse_f2(FullHouse);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        S_StraightButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    S_StraightButton_p2.setVisible(false);
                    JLabel S_StraightLabel_p2 = new JLabel("" + S_Straight);
                    total_score[1] += S_Straight;
                    UI.add(S_StraightLabel_p2);
                    S_StraightLabel_p2.setBounds(430, 425, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.s_straight_f2(S_Straight);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        L_StraightButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    L_StraightButton_p2.setVisible(false);
                    JLabel L_StraightLabel_p2 = new JLabel("" + L_Straight);
                    total_score[1] += L_Straight;
                    UI.add(L_StraightLabel_p2);
                    L_StraightLabel_p2.setBounds(430, 455, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.l_straight_f2(L_Straight);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
        YachtButton_p2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (count != 0 && T == 1) {
                    b1.setText("잠그기_1");
                    d1lock = 1;
                    b2.setText("잠그기_2");
                    d2lock = 1;
                    b3.setText("잠그기_3");
                    d3lock = 1;
                    b4.setText("잠그기_4");
                    d4lock = 1;
                    b5.setText("잠그기_5");
                    d5lock = 1;
                    YachtButton_p2.setVisible(false);
                    JLabel YachtLabel_p2 = new JLabel("" + Yacht);
                    total_score[1] += Yacht;
                    UI.add(YachtLabel_p2);
                    YachtLabel_p2.setBounds(430, 485, 100, 30);
                    T = turn_change(T);
                    BtnReset();
                    count = 0;
                    total_turn++;
                    p2.yacht_f2(Yacht);
                    end_f();
                    Aces = 0;
                    Deuces = 0;
                    Threes = 0;
                    Fours = 0;
                    Fives = 0;
                    Sixes = 0;
                    Choice = 0;
                    FourOfKind = 0;
                    FullHouse = 0;
                    S_Straight = 0;
                    L_Straight = 0;
                    Yacht = 0;
                }
            }
        });
    }

    public static void BtnReset()
    {
        if(T == 0)
        {
            AcesButton_p2.setText("?");
            DeuceButton_p2.setText("?");
            ThreesButton_p2.setText("?");
            FoursButton_p2.setText("?");
            FivesButton_p2.setText("?");
            SixesButton_p2.setText("?");
            ChoiceButton_p2.setText("?");
            FourOfKindButton_p2.setText("?");
            FullHouseBUtton_p2.setText("?");
            S_StraightButton_p2.setText("?");
            L_StraightButton_p2.setText("?");
            YachtButton_p2.setText("?");
        }
        else {
            AcesButton_p1.setText("?");
            DeuceButton_p1.setText("?");
            ThreesButton_p1.setText("?");
            FoursButton_p1.setText("?");
            FivesButton_p1.setText("?");
            SixesButton_p1.setText("?");
            ChoiceButton_p1.setText("?");
            FourOfKindButton_p1.setText("?");
            FullHouseBUtton_p1.setText("?");
            S_StraightButton_p1.setText("?");
            L_StraightButton_p1.setText("?");
            YachtButton_p1.setText("?");
        }
    }

    public static void BtnUpdate()
    {
        if(T == 0)
        {
            AcesButton_p1.setText(String.valueOf(Aces));
            DeuceButton_p1.setText(String.valueOf(Deuces));
            ThreesButton_p1.setText(String.valueOf(Threes));
            FoursButton_p1.setText(String.valueOf(Fours));
            FivesButton_p1.setText(String.valueOf(Fives));
            SixesButton_p1.setText(String.valueOf(Sixes));
            ChoiceButton_p1.setText(String.valueOf(Choice));
            FourOfKindButton_p1.setText(String.valueOf(FourOfKind));
            FullHouseBUtton_p1.setText(String.valueOf(FullHouse));
            S_StraightButton_p1.setText(String.valueOf(S_Straight));
            L_StraightButton_p1.setText(String.valueOf(L_Straight));
            YachtButton_p1.setText(String.valueOf(Yacht));

            AcesButton_p2.setText("?");
            DeuceButton_p2.setText("?");
            ThreesButton_p2.setText("?");
            FoursButton_p2.setText("?");
            FivesButton_p2.setText("?");
            SixesButton_p2.setText("?");
            ChoiceButton_p2.setText("?");
            FourOfKindButton_p2.setText("?");
            FullHouseBUtton_p2.setText("?");
            S_StraightButton_p2.setText("?");
            L_StraightButton_p2.setText("?");
            YachtButton_p2.setText("?");
        }
        else {
            AcesButton_p1.setText("?");
            DeuceButton_p1.setText("?");
            ThreesButton_p1.setText("?");
            FoursButton_p1.setText("?");
            FivesButton_p1.setText("?");
            SixesButton_p1.setText("?");
            ChoiceButton_p1.setText("?");
            FourOfKindButton_p1.setText("?");
            FullHouseBUtton_p1.setText("?");
            S_StraightButton_p1.setText("?");
            L_StraightButton_p1.setText("?");
            YachtButton_p1.setText("?");

            AcesButton_p2.setText(String.valueOf(Aces));
            DeuceButton_p2.setText(String.valueOf(Deuces));
            ThreesButton_p2.setText(String.valueOf(Threes));
            FoursButton_p2.setText(String.valueOf(Fours));
            FivesButton_p2.setText(String.valueOf(Fives));
            SixesButton_p2.setText(String.valueOf(Sixes));
            ChoiceButton_p2.setText(String.valueOf(Choice));
            FourOfKindButton_p2.setText(String.valueOf(FourOfKind));
            FullHouseBUtton_p2.setText(String.valueOf(FullHouse));
            S_StraightButton_p2.setText(String.valueOf(S_Straight));
            L_StraightButton_p2.setText(String.valueOf(L_Straight));
            YachtButton_p2.setText(String.valueOf(Yacht));
        }
    }
    void end_f()
    {
        Turn_Label.setText("Turn : "+(total_turn/2+1)+" / 12" + " - P" + (T + 1) + " Turn");

        subtotal_label_p1.setText(String.valueOf(subtotal[0]) + " / 63");
        subtotal_label_p2.setText(String.valueOf(subtotal[1]) + " / 63");
        total_Label_p1.setText(String.valueOf(total_score[0]));
        total_Label_p2.setText(String.valueOf(total_score[1]));

        if(total_turn/2 == 12)
        {
            JFrame EndFrame = new JFrame();
            EndFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            EndFrame.setTitle("결과!");
            EndFrame.setSize(300,200);
            EndFrame.setLocation(400, 400);
            EndFrame.setVisible(true);
            for(int i=0;i<12;i++)
            {
                System.out.println(table_p1[i]);
                System.out.println(table_p2[i]);
            }
            if(total_score[0]>total_score[1])
            {
                JLabel endcard = new JLabel();
                JLabel endcong = new JLabel();
                endcard.setText("Player 1: " + total_score[0] + "        Player 2: " + total_score[1]);
                endcong.setText("        Player1의 승리입니다!");
                EndFrame.add(endcard);
                EndFrame.add(endcong);
            }
            else if(total_score[0]<total_score[1])
            {
                JLabel endcard = new JLabel();
                endcard.setText("        Player2의 승리입니다!");
                EndFrame.add(endcard);
            }
            else
            {
                JLabel endcard = new JLabel();
                endcard.setText("        무승부입니다.");
                EndFrame.add(endcard);
            }

        }
    }

    public int turn_change(int T) // 턴변경을 위한 함수 제작중
    {
        if(T==0)
        {
            return 1;
        }
        else
        {
            return 0;
        }

    }

    /*public void Subtotal(int T)
    {
        if(subtotal[T] >= 63)
        {
            total_score[T] += 35;
        }
    }*/
    public void paint(Graphics g)
    {
        g.clearRect(0,0,550,580);
    }
}
//이게 표 생성 클래스 전문

// 주사위 창 생성
class game_Frame extends Player
{
    Random rand = new Random();

    int f_width = 800;
    int f_height = 700;

    //이미지를 불러오기 위한 툴킷
    static Toolkit tk = Toolkit.getDefaultToolkit();

    // 1~6 눈금 주사위 이미지 (경로 복사해서 넣으면 되고 뒤에 확장자 png 필수)
    static Image randImg = tk.getImage("Random.png");
    static Image aceImg = tk.getImage("Ace.png");
    static Image duceImg = tk.getImage("Duce.png");
    static Image threeImg = tk.getImage("Three.png");
    static Image fourImg = tk.getImage("Four.png");
    static Image fiveImg = tk.getImage("Five.png");
    static Image sixImg = tk.getImage("Six.png");

    // 게임 안에서 출력될 첫번째부터 다섯번째 주사위 이미지 변수
    static Image d1Img;
    static Image d2Img;
    static Image d3Img;
    static Image d4Img;
    static Image d5Img;
    //마지막 버튼의 크기가 최대가 되버리는 이상한 오류때문에 7번째 버튼을 생성해주고 안보이게 함으로써 해결

    game_Frame()
    {
        init();
        start();

        setTitle("주사위");

        //JFrame Game = new JFrame("주사위");
        //Game.setBounds(1075,150,f_width,f_height);
        //Game.setVisible(true);
        //Game.setResizable(false);

        // 리롤 버튼
        JButton roll = new JButton("굴리기");
        add(roll);
        roll.setBounds(225, 500, 300, 100);

        JButton bk = new JButton("버그킬러");
        add(bk);
        bk.setBounds(0, 50, 500, 50);
        bk.setVisible(false);

        roll.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                if(count/3!=1) {
                    repaint();
                    System.out.println("roll clicked");
                    Categories p = new Categories();
                    if (T == 0) {
                        p = new Player1();
                        System.out.println("플레이어1 턴 시작");
                    } else if (T == 1) {
                        p = new Player2();
                        System.out.println("플레이어2 턴 시작");
                    }
                    //JButton roll = (JButton) e.getSource();
                    if (d1lock == 1) {
                        d1 = rand.nextInt(6) + 1;
                    }
                    if (d2lock == 1) {
                        d2 = rand.nextInt(6) + 1;
                    }
                    if (d3lock == 1) {
                        d3 = rand.nextInt(6) + 1;
                    }
                    if (d4lock == 1) {
                        d4 = rand.nextInt(6) + 1;
                    }
                    if (d5lock == 1) {
                        d5 = rand.nextInt(6) + 1;
                    }

                    if (count == 0)
                    {
                        roll.setText("2회 남음");
                    }
                    else if (count == 1)
                    {
                        roll.setText("1회 남음");
                    }
                    else if (count == 2)
                    {
                        roll.setText("0회 남음");
                    }

                    if (T == 0) {
                        System.out.println("플레이어1 턴");
                    } else if (T == 1) {
                        System.out.println("플레이어2 턴");
                    }
                    p.Numbering(d1, d2, d3, d4, d5, T);
                    count++;
                    System.out.println("p1 " + total_score[0] + " p2 " + total_score[1]);
                }
                else
                {
                    roll.setText("기입하세요!");
                }
            }
        });

        setSize(f_width, f_height);

        Dimension screen = tk.getScreenSize();

        int f_xpos = 1000;//(int)(screen.getWidth() / 2 - f_width / 2);
        int f_ypos = 150;//(int)(screen.getHeight() / 2 - f_height / 2);

        setLocation(f_xpos, f_ypos);
        setResizable(false);
        setVisible(true);
    }

    public void init()
    {

    }

    public void start()
    {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void paint(Graphics g)
    {
        // 0,0 에서 위에서 정한 해상도 크기만큼 화면을 지웁니다.
        g.clearRect(0, 0, f_width, f_height);

        if(d1 == 1)
        {
            d1Img = aceImg;
        }
        else if(d1 == 2)
        {
            d1Img = duceImg;
        }
        else if(d1 == 3)
        {
            d1Img = threeImg;
        }
        else if(d1 == 4)
        {
            d1Img = fourImg;
        }
        else if(d1 == 5)
        {
            d1Img = fiveImg;
        }
        else if(d1 == 6)
        {
            d1Img = sixImg;
        }
        else
        {
            d1Img = randImg;
        }
        if(d2 == 1)
        {
            d2Img = aceImg;
        }
        else if(d2 == 2)
        {
            d2Img = duceImg;
        }
        else if(d2 == 3)
        {
            d2Img = threeImg;
        }
        else if(d2 == 4)
        {
            d2Img = fourImg;
        }
        else if(d2 == 5)
        {
            d2Img = fiveImg;
        }
        else if(d2 == 6)
        {
            d2Img = sixImg;
        }
        else
        {
            d2Img = randImg;
        }
        if(d3 == 1)
        {
            d3Img = aceImg;
        }
        else if(d3 == 2)
        {
            d3Img = duceImg;
        }
        else if(d3 == 3)
        {
            d3Img = threeImg;
        }
        else if(d3 == 4)
        {
            d3Img = fourImg;
        }
        else if(d3 == 5)
        {
            d3Img = fiveImg;
        }
        else if(d3 == 6)
        {
            d3Img = sixImg;
        }
        else
        {
            d3Img = randImg;
        }
        if(d4 == 1)
        {
            d4Img = aceImg;
        }
        else if(d4 == 2)
        {
            d4Img = duceImg;
        }
        else if(d4 == 3)
        {
            d4Img = threeImg;
        }
        else if(d4 == 4)
        {
            d4Img = fourImg;
        }
        else if(d4 == 5)
        {
            d4Img = fiveImg;
        }
        else if(d4 == 6)
        {
            d4Img = sixImg;
        }
        else
        {
            d4Img = randImg;
        }
        if(d5 == 1)
        {
            d5Img = aceImg;
        }
        else if(d5 == 2)
        {
            d5Img = duceImg;
        }
        else if(d5 == 3)
        {
            d5Img = threeImg;
        }
        else if(d5 == 4)
        {
            d5Img = fourImg;
        }
        else if(d5 == 5)
        {
            d5Img = fiveImg;
        }
        else if(d5 == 6)
        {
            d5Img = sixImg;
        }
        else
        {
            d5Img = randImg;
        }

        // 이미지 출력 - 순서대로 주사위 1, 2, 3, 4, 5
        g.drawImage(d1Img, 100, 150, this);
        g.drawImage(d2Img, 325, 150, this);
        g.drawImage(d3Img, 550, 150, this);
        g.drawImage(d4Img, 210, 350, this);
        g.drawImage(d5Img, 445, 350, this);
    }

    // 이미지 최신화
    public void update(Graphics g)
    {
        paint(g);
    }
}

class Categories extends JFrame// 표와 관련된 부모 클래스
{
    static int Aces = 0, Deuces = 0, Threes = 0, Fours = 0, Fives = 0, Sixes = 0;
    static int Choice = 0, FourOfKind = 0, FullHouse = 0, S_Straight = 0, L_Straight = 0, Yacht = 0;
    static int T;
    static int[] table_p1 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    static int[] table_p2 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    //int T = 0;  //0 = p1, 1 = p2
    static int subtotal[] = {0,0}; //보너스를 위한 카운트
    static int total_score[] = {0,0}; //총 점수
    //int number_choice = 0; //표 선택을 위한 변수
    int n1=0;
    int n2=0;
    int n3=0;
    int n4=0;
    int n5=0;
    int n6=0;

    public void Numbering(int d1, int d2, int d3, int d4, int d5, int turn) //주사위 굴리는 곳에서 호출
    {
        n1=0; n2=0; n3=0; n4=0; n5=0; n6=0;
        int[] dice = {d1, d2, d3, d4, d5};
        for(int i=0;i<5;i++)
        {
            switch (dice[i])
            {
                case 1:
                    n1 += 1;
                    break;
                case 2:
                    n2 += 1;
                    break;
                case 3:
                    n3 += 1;
                    break;
                case 4:
                    n4 += 1;
                    break;
                case 5:
                    n5 += 1;
                    break;
                case 6:
                    n6 += 1;
                    break;
                default:
                    break;
            }
        }
        System.out.println("1 개수 " + n1 + " 2 개수 " + n2 + " 3 개수 " + n3 + " 4 개수 " + n4 + " 5 개수 " + n5 + " 6 개수 " + n6);
        Show_Table(n1,n2,n3,n4,n5,n6,turn);
    }


    public void Show_Table(int n1, int n2, int n3, int n4, int n5, int n6, int turn)
    {
        T = turn;
        //라벨, 버튼으로 값표기
        Aces = n1; //numbers
        Deuces = n2 * 2;
        Threes = n3 * 3;
        Fours = n4 * 4;
        Fives = n5 * 5;
        Sixes = n6 * 6;
        Choice = n1 + (n2 * 2) + (n3 * 3) + (n4 * 4) + (n5 * 5) + (n6 * 6);

        if (n1 >= 4 || n2 >= 4 || n3 >= 4 || n4 >= 4 || n5 >= 4 || n6 >= 4) //FourOfKind
            FourOfKind = n1 + (n2 * 2) + (n3 * 3) + (n4 * 4) + (n5 * 5) + (n6 * 6);
        else
            FourOfKind = 0;

        int[] fullhouse = {n1, n2, n3, n4, n5, n6}; //FullHouse
        int threes = 0, deuces = 0, i, j;
        for (i = 0; i < 6; i++) {
            if (fullhouse[i] == 3) {
                threes = i + 1;
                break;
            }
        }
        for (j = 0; j < 6; j++) {
            if (fullhouse[j] == 2) {
                deuces = j + 1;
                break;
            }
        }
        if(threes!=0 && deuces != 0)
            FullHouse = threes * 3 + deuces * 2;
        else
            FullHouse = 0;

        if (n1 > 0 && n2 > 0 && n3 > 0 && n4 > 0) //S_Straight
            S_Straight = 15;
        else if (n2 > 0 && n3 > 0 && n4 > 0 && n5 > 0)
            S_Straight = 15;
        else if (n3 > 0 && n4 > 0 && n5 > 0 && n6 > 0)
            S_Straight = 15;
        else
            S_Straight = 0;

        if (n1 > 0 && n2 > 0 && n3 > 0 && n4 > 0 && n5 > 0) //L_Straight
            L_Straight = 30;
        else if (n2 > 0 && n3 > 0 && n4 > 0 && n5 > 0 && n6 > 0)
            L_Straight = 30;
        else
            L_Straight = 0;

        if (n1 == 5 || n2 == 5 || n3 == 5 || n4 == 5 || n5 == 5 || n6 == 5)
            Yacht = 50;
        else
            Yacht = 0;

        System.out.println("ace " + Aces + " duce " + Deuces + " three " + Threes + " four " + Fours + " five " + Fives + " six " + Sixes);
        System.out.println("cho " + Choice + " fk " + FourOfKind + " fh " + FullHouse + " ss " + S_Straight + " ls " + L_Straight + " yyy " + Yacht);
        System.out.println("player"+(T+1));

        Player p = new Player();
        Player.BtnUpdate();

        //Show.AcesButton
        //Show(Aces, Deuces, Threes, Fours, Fives, Sixes, Choice, FourOfKind, FullHouse, S_Straight, L_Straight, Yacht, T);

        //if(T==0)
        //p.player1(Aces, Deuces, Threes, Fours,Fives,Sixes, Choice, FourOfKind, FullHouse, S_Straight, L_Straight, Yacht);
        //else
        //p.player2(Aces, Deuces, Threes, Fours,Fives,Sixes, Choice, FourOfKind, FullHouse, S_Straight, L_Straight, Yacht);
        //p.Show();
    }
    //public void Numbers_choice(int T) //버튼으로 표 선택
    //{
    //1~6, 족보의 숫자를 라벨 또는 버튼으로 출력
    //}



}//이게 주사위 눈 측정 클래스

