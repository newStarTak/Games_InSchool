public class Player1 extends Categories
{
    void Aces_f1(int a)
    {
        table_p1[0] = a;
    }
    void Deuces_f1(int a)
    {
        table_p1[1] = a;
    }
    void threes_f1(int a)
    {
        table_p1[2] = a;
    }
    void fours_f1(int a)
    {
        table_p1[3] = a;
    }
    void fives_f1(int a)
    {
        table_p1[4] = a;
    }
    void sixes_f1(int a)
    {
        table_p1[5] = a;
    }
    void choices_f1(int a)
    {
        table_p1[6] = a;
    }
    void fourofkind_f1(int a)
    {
        table_p1[7] = a;
    }
    void fullhouse_f1(int a)
    {
        table_p1[8] = a;
    }
    void s_straight_f1(int a)
    {
        table_p1[9] = a;
    }
    void l_straight_f1(int a)
    {
        table_p1[10] = a;
    }
    void yacht_f1(int a)
    {
        table_p1[11] = a;
    }
}
//p1 변수저장 클래스