public class Player2 extends Categories
{
    void Aces_f2(int a)
    {
        table_p2[0] = a;
    }
    void Deuces_f2(int a)
    {
        table_p2[1] = a;
    }
    void threes_f2(int a)
    {
        table_p2[2] = a;
    }
    void fours_f2(int a)
    {
        table_p2[3] = a;
    }
    void fives_f2(int a)
    {
        table_p2[4] = a;
    }
    void sixes_f2(int a)
    {
        table_p2[5] = a;
    }
    void choices_f2(int a)
    {
        table_p2[6] = a;
    }
    void fourofkind_f2(int a)
    {
        table_p2[7] = a;
    }
    void fullhouse_f2(int a)
    {
        table_p2[8] = a;
    }
    void s_straight_f2(int a)
    {
        table_p2[9] = a;
    }
    void l_straight_f2(int a)
    {
        table_p2[10] = a;
    }
    void yacht_f2(int a)
    {
        table_p2[11] = a;
    }
}
//p2 변수 저장 클래스